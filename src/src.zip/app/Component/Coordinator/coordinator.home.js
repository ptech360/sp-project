"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var organization_service2_1 = require('../../providers/organization.service2');
var common_service_1 = require('../../providers/common.service');
var forms_1 = require('@angular/forms');
var CoordinatorHome = (function () {
    function CoordinatorHome(orgSer, cs) {
        var _this = this;
        this.orgSer = orgSer;
        this.cs = cs;
        this.displayProfile = true;
        this.assignedActivities = [];
        this.departments = [];
        this.cs.getData('user_roleInfo').forEach(function (element) {
            _this.departments.push(element.departmentId);
        });
        this.evidencForm = new forms_1.FormGroup({
            title: new forms_1.FormControl('', [forms_1.Validators.required]),
            description: new forms_1.FormControl('', forms_1.Validators.required),
            files: new forms_1.FormControl('', [forms_1.Validators.required])
        });
        this.discussionForm = new forms_1.FormGroup({
            comment: new forms_1.FormControl('', [forms_1.Validators.required])
        });
        this.orgSer.fetchAssignedActivity(this.departments).subscribe(function (res) {
            if (res.status != 204) {
                _this.assignedActivities = res;
            }
            else {
                _this.assignedActivities = [];
            }
        });
        this.currentUser = this.cs.getData('userDetails').id;
    }
    CoordinatorHome.prototype.saveResult = function (e) {
        var result = {
            "currentLevel": e.currentLevel,
            "currentCost": e.currentCost,
            "departmentId": this.cs.getData("user_roleInfo")[0].departmentId,
        };
        if (e.status == null) {
            result["quarterId"] = e.quarterId;
            this.orgSer.saveQuarteResult(result, e.quarterId).subscribe(function (res) {
                console.log("success", res);
                e.status = "inprogress";
                e.id = res.results[0].id;
            });
        }
        else {
            this.orgSer.updateQuarteResult(result, e.id).subscribe(function (res) {
                console.log("success");
                e.status = "inprogress";
            });
        }
    };
    CoordinatorHome.prototype.getFile = function (event) {
        this.file = event.srcElement.files[0];
        console.log(event.srcElement.files[0]);
    };
    CoordinatorHome.prototype.onEvidenceSubmit = function () {
        var _this = this;
        var formData = new FormData();
        formData.append('title', this.evidencForm.value['title']);
        formData.append('description', this.evidencForm.value['description']);
        formData.append('file', this.file);
        console.log(this.evidencForm.value);
        this.orgSer.saveEvidence(formData, this.selectedQuarter.id).subscribe(function (res) {
            if (!_this.selectedQuarter.evidance)
                _this.selectedQuarter.evidance = [];
            _this.selectedQuarter.evidance.push(res);
            $('#evidenceForm').modal('hide');
        });
    };
    CoordinatorHome.prototype.commentPost = function () {
        this.discussionForm.value["quarterLevelResultId"] = this.selectedQuarter.id;
        this.discussionForm.value["employeeId"] = this.cs.getData('userDetails').id;
        this.discussionForm.value["commentedOn"] = new Date();
        this.orgSer.saveComment(this.selectedQuarter.id, this.discussionForm.value).subscribe(function (response) {
            console.log(response);
        });
    };
    CoordinatorHome.prototype.lockResult = function (lev) {
        this.orgSer.lockResult(lev.id).subscribe(function (res) {
            lev.status = "locked";
            console.log(res);
        });
    };
    CoordinatorHome.prototype.logout = function () {
        localStorage.clear();
    };
    CoordinatorHome = __decorate([
        core_1.Component({
            selector: 'coordinator-home',
            templateUrl: './coordinator.home.html',
            styleUrls: ['./../Planner/objective/objective.css', './coordinator.home.css', './../Planner/planner.home.css']
        }), 
        __metadata('design:paramtypes', [organization_service2_1.OrganizationService2, common_service_1.CommonService])
    ], CoordinatorHome);
    return CoordinatorHome;
}());
exports.CoordinatorHome = CoordinatorHome;
//# sourceMappingURL=coordinator.home.js.map