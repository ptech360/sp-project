"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var common_service_1 = require('../../../providers/common.service');
var router_1 = require('@angular/router');
var organization_service2_1 = require('../../../providers/organization.service2');
var InitialStetup = (function () {
    function InitialStetup(formBuilder, orgService, commonService, router) {
        this.formBuilder = formBuilder;
        this.orgService = orgService;
        this.commonService = commonService;
        this.router = router;
        this.returnObject = [];
        this.cycle = [];
        this.submitted = false;
        if (this.commonService.getData('org_info')[0].cycles) {
            this.router.navigate(['/' + this.commonService.getData('user_roleInfo')[0].role + '-home']);
        }
    }
    InitialStetup.prototype.ngOnInit = function () {
        this.uid = this.getUniversity();
        this.cmvvForm = this.formBuilder.group({
            "startCycle": ['', [forms_1.Validators.required]],
            "endCycle": ['', [forms_1.Validators.required]],
            "mission": ['', [forms_1.Validators.required]],
            "vision": ['', [forms_1.Validators.required]],
            "values": this.formBuilder.array([this.inItValue()])
        });
    };
    InitialStetup.prototype.inItValue = function () {
        return this.formBuilder.group({
            "title": ['', [forms_1.Validators.required]],
            "description": ['', [forms_1.Validators.required]]
        });
    };
    InitialStetup.prototype.removeValue = function (index) {
        var control = this.cmvvForm.controls['values'];
        control.removeAt(index);
    };
    InitialStetup.prototype.addValue = function () {
        var control = this.cmvvForm.controls['values'];
        control.push(this.inItValue());
    };
    InitialStetup.prototype.getUniversity = function () {
        var _this = this;
        this.orgService.getUniversities().subscribe(function (response) {
            _this.uid = response[0].id;
        }, function (error) {
            console.log(error);
        });
    };
    InitialStetup.prototype.onSubmit = function () {
        var _this = this;
        this.cmvvForm.value['universityId'] = this.commonService.getData("org_info")[0].id;
        var startYear = new Date(this.cmvvForm.value.startCycle).getFullYear();
        var endYear = new Date(this.cmvvForm.value.endCycle).getFullYear();
        for (var y = startYear; y <= endYear; y++)
            this.cycle.push(y);
        this.cmvvForm.value['cycle'] = {
            "startCycle": this.cmvvForm.value.startCycle,
            "endCycle": this.cmvvForm.value.endCycle
        };
        delete this.cmvvForm.value['startCycle'];
        delete this.cmvvForm.value['endCycle'];
        this.orgService.orgInitialSetup(this.cmvvForm.value).subscribe(function (res) {
            _this.returnObject.push(res);
            _this.returnObject['cycle'] = _this.cycle;
            _this.commonService.storeData('org_info', _this.returnObject);
            _this.router.navigate(['/planner']);
        }, function (error) {
            console.log(error);
        });
    };
    InitialStetup = __decorate([
        core_1.Component({
            selector: 'initialSetup',
            templateUrl: './initial.setup.html',
            styleUrls: ['']
        }), 
        __metadata('design:paramtypes', [forms_1.FormBuilder, organization_service2_1.OrganizationService2, common_service_1.CommonService, router_1.Router])
    ], InitialStetup);
    return InitialStetup;
}());
exports.InitialStetup = InitialStetup;
//# sourceMappingURL=initial.setup.js.map