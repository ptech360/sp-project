"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var organization_service2_1 = require('../../../providers/organization.service2');
var common_service_1 = require('../../../providers/common.service');
var ObjectiveComponent = (function () {
    function ObjectiveComponent(orgSer, commonService, formBuilder) {
        var _this = this;
        this.orgSer = orgSer;
        this.commonService = commonService;
        this.formBuilder = formBuilder;
        this.empty = false;
        this.quarter = ["First", "Second", "Third", "Forth"];
        orgSer.fetchObjectives(commonService.getData('org_info').cycles.id).subscribe(function (res) {
            if (res.status == 204) {
                _this.empty = false;
                _this.objectives = [];
            }
            else {
                _this.objectives = res;
            }
            console.log(res);
        });
        this.initObjectiveForm();
        this.initiativeForm = this.initForm();
        this.activityForm = this.setActivity();
        this.measureForm = this.setMeasure();
    }
    // getInitiative(objectiveId:any){
    //   this.orgSer.fetchInitiative(objectiveId).subscribe( (res:any) =>{
    //     this.initiatives = res.initiatives;
    //   })
    // }
    ObjectiveComponent.prototype.ngAfterViewInit = function () {
        $('.panel-collapse').on('hidden.bs.collapse', function () {
            // find the children and close them
            $(this).find('.collapse').collapse('hide');
        });
    };
    /**Objective Component */
    ObjectiveComponent.prototype.initObjectiveForm = function () {
        this.objectiveForm = this.formBuilder.group({
            "objective": ['', [forms_1.Validators.required]],
            "totalCost": ['', [forms_1.Validators.required]],
            "spis": this.formBuilder.array([this.inItSpi()]),
        });
    };
    ObjectiveComponent.prototype.inItSpi = function () {
        return this.formBuilder.group({
            "spi": ['', [forms_1.Validators.required]],
            "measureUnit": ['', [forms_1.Validators.required]],
            "currentLevel": ['', [forms_1.Validators.required]],
            "frequencyId": [1],
            "targetDigital": this.formBuilder.array(this.inItTarget())
        });
    };
    ObjectiveComponent.prototype.inItTargetDigital = function (year) {
        return this.formBuilder.group({
            "year": [year, [forms_1.Validators.required]],
            "expectedLevel": ['', [forms_1.Validators.required]],
        });
    };
    ObjectiveComponent.prototype.inItTarget = function () {
        var _this = this;
        var fa = [];
        this.commonService.getData('org_info').cycle.forEach(function (element) {
            fa.push(_this.inItTargetDigital(element));
        });
        return fa;
    };
    ObjectiveComponent.prototype.addSpi = function (form) {
        var control = form.controls['spis'];
        control.push(this.inItSpi());
    };
    ObjectiveComponent.prototype.removeSpi = function (form, index) {
        var control = form.controls['spis'];
        control.removeAt(index);
    };
    ObjectiveComponent.prototype.onSubmit = function () {
        var _this = this;
        this.objectiveForm.value["cycleId"] = this.commonService.getData('org_info').cycles.id;
        this.orgSer.addObjective(this.objectiveForm.value).subscribe(function (response) {
            $('#objectiveModal').modal('hide');
            _this.returnedObject = response;
            _this.objectives.push(_this.returnedObject);
            _this.initObjectiveForm();
        }, function (error) {
            console.log(error);
        });
    };
    /**************** end of objective component ***********************/
    /**************** Initiative Component ************************** */
    ObjectiveComponent.prototype.initForm = function () {
        return this.formBuilder.group({
            "initiative": ['', [forms_1.Validators.required]],
            "totalCost": ['', [forms_1.Validators.required]],
            "activities": this.formBuilder.array([this.setActivity()])
        });
    };
    ObjectiveComponent.prototype.addActivity = function (form) {
        var control = form.controls['activities'];
        control.push(this.setActivity());
    };
    ObjectiveComponent.prototype.removeActivity = function (form, i) {
        var control = form.controls['activities'];
        control.removeAt(i);
    };
    ObjectiveComponent.prototype.addMeasure = function (form) {
        var control = form.controls['measures'];
        control.push(this.setMeasure());
    };
    ObjectiveComponent.prototype.removeMeasure = function (form, j) {
        var control = form.controls['measures'];
        control.removeAt(j);
    };
    ObjectiveComponent.prototype.setActivity = function () {
        return this.formBuilder.group({
            "activity": ['', [forms_1.Validators.required]],
            "measures": this.formBuilder.array([this.setMeasure()])
        });
    };
    ObjectiveComponent.prototype.setMeasure = function () {
        return this.formBuilder.group({
            "measure": ['', [forms_1.Validators.required]],
            "frequencyId": [1, [forms_1.Validators.required]],
            "measureUnit": ['', [forms_1.Validators.required]],
            "currentLevel": ['', [forms_1.Validators.required]],
            "direction": ['', [forms_1.Validators.required]],
            "annualTarget": this.formBuilder.array(this.setAnnualTarget())
        });
    };
    ObjectiveComponent.prototype.setAnnualTarget = function () {
        var _this = this;
        var annualTarget = [];
        this.commonService.getData('org_info').cycle.forEach(function (element) {
            annualTarget.push(_this.inItTargetIn(element));
        });
        return annualTarget;
    };
    ObjectiveComponent.prototype.inItTargetIn = function (year) {
        return this.formBuilder.group({
            "year": [year, [forms_1.Validators.required]],
            "levels": this.formBuilder.array([this.inItLevels(this.quarter[0])]),
            "estimatedCost": ['', [forms_1.Validators.required]]
        });
    };
    ObjectiveComponent.prototype.setTargetTable = function (form, e) {
        for (var index = 0; index < this.commonService.getData('org_info').cycle.length; index++) {
            form[index].controls['levels'] = this.formBuilder.array([]);
            var levels = form[index].controls['levels'];
            for (var i = 0; i < e; i++) {
                levels.push(this.inItLevels(this.quarter[i]));
            }
        }
    };
    ObjectiveComponent.prototype.inItLevels = function (q) {
        return this.formBuilder.group({
            "quarter": [q],
            "startDate": ["2017-04-01"],
            "endDate": ["2018-04-15"],
            "estimatedTargetLevel": ['', [forms_1.Validators.required]]
        });
    };
    ObjectiveComponent.prototype.submitInitiative = function () {
        var _this = this;
        this.initiativeForm.value['objectiveId'] = this.selectedObjective.id;
        this.orgSer.addInitiative(this.initiativeForm.value).subscribe(function (res) {
            _this.selectedObjective.initiatives.push(res);
            $('#initiativeModal').modal('hide');
            _this.initForm();
        }, function (err) {
            console.log(err);
        });
    };
    ObjectiveComponent.prototype.submitActivity = function () {
        var _this = this;
        this.activityForm.value['initiativeId'] = this.selectedInitiative.id;
        this.orgSer.saveActivity(this.activityForm.value)
            .subscribe(function (response) {
            _this.selectedInitiative.activities.push(response);
            $('#activityModal').modal('hide');
            _this.activityForm = _this.setActivity();
        });
    };
    ObjectiveComponent.prototype.submitMeasure = function () {
        var _this = this;
        this.measureForm.value['activityId'] = this.selectedActivity.id;
        this.orgSer.saveMeasure(this.measureForm.value).subscribe(function (response) {
            _this.measureForm = _this.setMeasure();
            _this.selectedActivity.measures.push(response);
            $('#measureModal').modal('hide');
        }, function (error) {
            console.log(error);
        });
    };
    ObjectiveComponent.prototype.assignActivity = function (activity) {
        var _this = this;
        this.orgSer.assignActivity(activity.id, this.departmentIds).subscribe(function (res) {
            activity.assignedDepartments = activity.assignedDepartments.concat(res);
            activity.otherDepartments.forEach(function (oelement, index) {
                _this.departmentIds.forEach(function (ielement) {
                    if (ielement == oelement.departmentId) {
                        if (index !== -1) {
                            activity.otherDepartments.splice(index, 1);
                        }
                    }
                });
            });
        }, function (error) {
            console.log(error);
        });
    };
    ObjectiveComponent.prototype.getObjElement = function (event) {
        $('.objective').addClass('hideBtn');
        if (!event.srcElement.classList.contains('collapsed'))
            $('.objective').addClass('hideBtn');
        else
            event.srcElement.nextElementSibling.classList.remove('hideBtn');
    };
    ObjectiveComponent.prototype.getIniElement = function (event) {
        $('.initiative').addClass('hideBtn');
        if (!event.srcElement.classList.contains('collapsed'))
            $('.initiative').addClass('hideBtn');
        else
            event.srcElement.nextElementSibling.classList.remove('hideBtn');
    };
    ObjectiveComponent.prototype.getActElement = function (event) {
        $('.activity').addClass('hideBtn');
        if (!event.srcElement.classList.contains('collapsed'))
            $('.activity').addClass('hideBtn');
        else
            event.srcElement.nextElementSibling.classList.remove('hideBtn');
    };
    ObjectiveComponent.prototype.getRowSpan = function (array) {
        var rowSpan = 1;
        rowSpan += array.length;
        array.forEach(function (element) {
            rowSpan += element.activities.length;
            element.activities.forEach(function (innerElement) {
                rowSpan += innerElement.measures.length;
            });
        });
        if (rowSpan == 1)
            return rowSpan + 1;
        return rowSpan;
    };
    ObjectiveComponent.prototype.getRowSpanOfIni = function (array) {
        var rowSpan = 1;
        rowSpan += array.length * 2;
        array.forEach(function (innerElement) {
            rowSpan += innerElement.measures.length;
        });
        return rowSpan;
    };
    ObjectiveComponent = __decorate([
        core_1.Component({
            selector: 'objective',
            templateUrl: './objective.html',
            styleUrls: ['./objective.css']
        }), 
        __metadata('design:paramtypes', [organization_service2_1.OrganizationService2, common_service_1.CommonService, forms_1.FormBuilder])
    ], ObjectiveComponent);
    return ObjectiveComponent;
}());
exports.ObjectiveComponent = ObjectiveComponent;
//# sourceMappingURL=objective.js.map