"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var common_service_1 = require('../../../providers/common.service');
var organization_service2_1 = require('../../../providers/organization.service2');
var CycleComponent = (function () {
    function CycleComponent(commonService, orgSer) {
        this.commonService = commonService;
        this.orgSer = orgSer;
        this.valueForm = new forms_1.FormGroup({
            title: new forms_1.FormControl('', [forms_1.Validators.required]),
            description: new forms_1.FormControl('', forms_1.Validators.required),
        });
        this.missionVisionForm = new forms_1.FormGroup({
            description: new forms_1.FormControl('', forms_1.Validators.required)
        });
    }
    CycleComponent.prototype.ngOnInit = function () {
        this.organizationInfo = this.commonService.getData('org_info');
    };
    CycleComponent.prototype.onValueSubmit = function () {
        var _this = this;
        if (this.selectedValue) {
            this.orgSer.updateValue(this.valueForm.value, this.selectedValue.id)
                .subscribe(function (res) {
                _this.valueForm.value["id"] = _this.selectedValue.id;
                _this.organizationInfo.values[_this.selectedValueIndex] = _this.valueForm.value;
                _this.commonService.storeData('org_info', _this.organizationInfo);
                $('#valueForm').modal('hide');
                _this.valueForm.reset();
            });
        }
        else {
            this.valueForm.value["setupId"] = this.organizationInfo[0].setupId;
            this.orgSer.addValue([this.valueForm.value]).subscribe(function (res) {
                _this.organizationInfo.values.push(_this.valueForm.value);
                $('#valueForm').modal('hide');
                _this.valueForm.reset();
            });
        }
    };
    CycleComponent.prototype.deleteValue = function (val, index) {
        var _this = this;
        this.orgSer.deleteValue(val.id).subscribe(function (res) {
            _this.organizationInfo.values.splice(index, 1);
        });
    };
    CycleComponent.prototype.onValueSelected = function (val, index) {
        this.valueForm.controls["title"].patchValue(val.title);
        this.valueForm.controls["description"].patchValue(val.description);
        this.selectedValue = val;
        this.selectedValueIndex = index;
    };
    CycleComponent.prototype.editMisionVision = function (title) {
        console.log(title);
        this.missionVision = title;
    };
    CycleComponent.prototype.onMissionVisionSubmit = function () {
        var object = {
            id: this.commonService.getData('org_info')['setupId']
        };
        object[this.missionVision] = this.missionVisionForm.value['description'];
        this.orgSer.updateMisionVision(object).subscribe(function (res) {
            console.log(res);
        });
    };
    CycleComponent = __decorate([
        core_1.Component({
            selector: 'cycle',
            templateUrl: './cycle.html',
            styleUrls: ['./../planner.home.css']
        }), 
        __metadata('design:paramtypes', [common_service_1.CommonService, organization_service2_1.OrganizationService2])
    ], CycleComponent);
    return CycleComponent;
}());
exports.CycleComponent = CycleComponent;
//# sourceMappingURL=cycle.js.map