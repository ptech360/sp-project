"use strict";
/*Components*/
var login_1 = require('./Component/Login/login');
var home_1 = require('./Component/Admin/home/home');
var admin_home_1 = require('./Component/Admin/admin.home');
var new_university_component_1 = require('./Component/Admin/university/new.university.component');
var new_department_component_1 = require('./Component/Admin/department/new.department.component');
var new_employee_1 = require('./Component/Admin/employee/new.employee');
var existing_department_component_1 = require('./Component/Admin/department/existing.department.component');
var add_role_component_1 = require('./Component/Admin/employee/role/add.role.component');
var planner_home_1 = require('./Component/Planner/planner.home');
var initial_setup_1 = require('./Component/Planner/initial-setup/initial.setup');
var cycle_1 = require('./Component/Planner/cycle/cycle');
var objective_1 = require('./Component/Planner/objective/objective');
var coordinator_home_1 = require('./Component/Coordinator/coordinator.home');
var hod_home_1 = require('./Component/Hod/hod.home');
var login_guard_1 = require('./Component/Login/login.guard');
var cycle_check_1 = require('./Component/Planner/cycle/cycle.check');
exports.rootRouterConfig = [
    { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'login', component: login_1.Login },
    { path: 'admin', component: admin_home_1.AdminHome, canActivate: [login_guard_1.LoggedInGuard],
        children: [
            { path: 'home', component: home_1.Home },
            { path: 'new-university', component: new_university_component_1.NewUniversity, canActivate: [login_guard_1.LoggedInGuard] },
            { path: 'new-department', component: new_department_component_1.NewDepartment, canActivate: [login_guard_1.LoggedInGuard] },
            { path: 'new-employee', component: new_employee_1.NewEmployee, canActivate: [login_guard_1.LoggedInGuard] },
            { path: 'existing-department', component: existing_department_component_1.ExistingDepartment, canActivate: [login_guard_1.LoggedInGuard] },
            { path: 'add-role', component: add_role_component_1.AddRole, canActivate: [login_guard_1.LoggedInGuard] }
        ]
    },
    { path: 'planner', component: planner_home_1.PlannerHome, canActivate: [login_guard_1.LoggedInGuard],
        children: [
            { path: 'initialSetup', component: initial_setup_1.InitialStetup, },
            { path: '', component: cycle_1.CycleComponent, canActivate: [cycle_check_1.HaveCycle] },
            { path: 'objective', component: objective_1.ObjectiveComponent }
        ]
    },
    { path: 'coordinator', component: coordinator_home_1.CoordinatorHome, canActivate: [login_guard_1.LoggedInGuard] },
    { path: 'hod', component: hod_home_1.HodHome, canActivate: [login_guard_1.LoggedInGuard] },
    { path: 'chancellor', component: hod_home_1.HodHome, canActivate: [login_guard_1.LoggedInGuard] },
    { path: 'viceChancellor', component: hod_home_1.HodHome, canActivate: [login_guard_1.LoggedInGuard] },
    { path: 'deputyViceChancellor', component: hod_home_1.HodHome, canActivate: [login_guard_1.LoggedInGuard] }
];
//# sourceMappingURL=app.routes.js.map