"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var Observable_1 = require('rxjs/Observable');
var http_1 = require('@angular/http');
var common_service_1 = require('./common.service');
var default_header_service_1 = require('./default.header.service');
require('rxjs/add/operator/map');
require('rxjs/add/operator/catch');
require('rxjs/add/observable/throw');
var OrganizationService2 = (function () {
    function OrganizationService2(http, htttp, con) {
        this.http = http;
        this.htttp = htttp;
        this.con = con;
        this.baseUrl = "";
        this.baseUrl = con.baseUrl;
    }
    OrganizationService2.prototype.orgInitialSetup = function (data) {
        this.baseUrl = this.con.baseUrl;
        return this.http.post(this.baseUrl + "/initialSetup", data)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.addValue = function (val) {
        this.baseUrl = this.con.baseUrl;
        return this.http.post(this.baseUrl + "/values", val)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.updateValue = function (val, id) {
        this.baseUrl = this.con.baseUrl;
        return this.http.put(this.baseUrl + "/values/" + id, val)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.deleteValue = function (id) {
        this.baseUrl = this.con.baseUrl;
        return this.http.delete(this.baseUrl + "/values/" + id)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.getUniversities = function () {
        this.baseUrl = this.con.baseUrl;
        return this.http.get(this.baseUrl + "/university")
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.fetchOrganizationInfo = function () {
        this.baseUrl = this.con.baseUrl;
        return this.http.get(this.baseUrl + "/university")
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.fetchObjectives = function (cycleId) {
        this.baseUrl = this.con.baseUrl;
        return this.http.get(this.baseUrl + "/cycle/" + cycleId + "/objective")
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.addObjective = function (objective) {
        this.baseUrl = this.con.baseUrl;
        return this.http.post(this.baseUrl + "/objective", objective)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.addInitiative = function (initiative) {
        this.baseUrl = this.con.baseUrl;
        return this.http.post(this.baseUrl + "/initiative", initiative)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.fetchInitiative = function (goalId) {
        this.baseUrl = this.con.baseUrl;
        return this.http.get(this.baseUrl + "/objective/" + goalId + "/initiative")
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.fetchAssignedActivity = function (departmentIds) {
        this.baseUrl = this.con.baseUrl;
        return this.http.get(this.baseUrl + "/department/" + departmentIds + "/result")
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.saveQuarteResult = function (data, quarterId) {
        this.baseUrl = this.con.baseUrl;
        return this.http.post(this.baseUrl + "/result", data)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.updateQuarteResult = function (data, resultId) {
        this.baseUrl = this.con.baseUrl;
        return this.http.put(this.baseUrl + "/result/" + resultId, data)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.lockResult = function (resultId) {
        this.baseUrl = this.con.baseUrl;
        return this.http.put(this.baseUrl + "/result/" + resultId, { status: "locked" })
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.saveEvidence = function (data, resultId) {
        this.baseUrl = this.con.baseUrl;
        var options = new http_1.RequestOptions({
            headers: new http_1.Headers({
                'Authorization': 'Bearer ' + localStorage.getItem('access_token')
            })
        });
        return this.htttp.post(this.baseUrl + "/result/" + resultId + "/evidance", data, options)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.saveComment = function (resultId, comment) {
        this.baseUrl = this.con.baseUrl;
        return this.http.post(this.baseUrl + "/result/" + resultId + "/discussion", comment)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.fetchDepartments = function () {
        this.baseUrl = this.con.baseUrl;
        return this.http.get(this.baseUrl + "/university/1/department")
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.assignActivity = function (actId, departments) {
        this.baseUrl = this.con.baseUrl;
        return this.http.post(this.baseUrl + "/assign/activity/" + actId + "/departments", { 'departments': departments })
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.saveActivity = function (activity) {
        this.baseUrl = this.con.baseUrl;
        return this.http.post(this.baseUrl + "/activity", activity)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.saveSpi = function (spi) {
        this.baseUrl = this.con.baseUrl;
        return this.http.post(this.baseUrl + "/spi", spi)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.saveMeasure = function (measure) {
        this.baseUrl = this.con.baseUrl;
        return this.http.post(this.baseUrl + "/measures", measure)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.updateMisionVision = function (object) {
        this.baseUrl = this.con.baseUrl;
        return this.http.put(this.baseUrl + "/initialSetup", object)
            .map(this.extractData)
            .catch(this.handleError);
    };
    OrganizationService2.prototype.extractData = function (res) {
        if (res.status === 204) {
            return res;
        }
        var body = res.json();
        return body || {};
    };
    OrganizationService2.prototype.handleError = function (error) {
        var errMsg;
        if (error instanceof http_1.Response) {
            var body = error.json() || '';
            var err = body.error || JSON.stringify(body);
            errMsg = error.status + " - " + (error.statusText || '') + " " + err;
            if (error.status === 0) {
                errMsg = error.status + " - \"Something is wrong..\"";
            }
        }
        else {
            errMsg = error.message ? error.message : error.toString();
        }
        return Observable_1.Observable.throw(errMsg);
    };
    OrganizationService2 = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [default_header_service_1.CustomHttpService, http_1.Http, common_service_1.CommonService])
    ], OrganizationService2);
    return OrganizationService2;
}());
exports.OrganizationService2 = OrganizationService2;
//# sourceMappingURL=organization.service2.js.map