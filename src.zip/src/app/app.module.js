"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var platform_browser_1 = require('@angular/platform-browser');
var router_1 = require('@angular/router');
var app_routes_1 = require('./app.routes');
var forms_1 = require('@angular/forms');
/*Components */
var app_component_1 = require('./app.component');
var login_1 = require('./Component/Login/login');
var home_1 = require('./Component/Admin/home/home');
var admin_home_1 = require('./Component/Admin/admin.home');
var new_university_component_1 = require('./Component/Admin/university/new.university.component');
var new_department_component_1 = require('./Component/Admin/department/new.department.component');
var new_employee_1 = require('./Component/Admin/employee/new.employee');
var existing_department_component_1 = require('./Component/Admin/department/existing.department.component');
var add_role_component_1 = require('./Component/Admin/employee/role/add.role.component');
var planner_home_1 = require('./Component/Planner/planner.home');
var initial_setup_1 = require('./Component/Planner/initial-setup/initial.setup');
var cycle_1 = require('./Component/Planner/cycle/cycle');
var objective_1 = require('./Component/Planner/objective/objective');
var coordinator_home_1 = require('./Component/Coordinator/coordinator.home');
var hod_home_1 = require('./Component/Hod/hod.home');
var objective_component_1 = require('./Component/CommonTamplates/objective.component');
/* Providers */
var login_guard_1 = require('./Component/Login/login.guard');
var cycle_check_1 = require('./Component/Planner/cycle/cycle.check');
var admin_service_1 = require('./providers/admin.service');
var common_service_1 = require('./providers/common.service');
var credential_service_1 = require('./providers/credential.service');
var organization_service2_1 = require('./providers/organization.service2');
var default_header_service_1 = require('./providers/default.header.service');
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [platform_browser_1.BrowserModule,
                forms_1.ReactiveFormsModule,
                http_1.HttpModule,
                forms_1.FormsModule,
                router_1.RouterModule.forRoot(app_routes_1.rootRouterConfig, { useHash: true })],
            declarations: [app_component_1.AppComponent, login_1.Login, home_1.Home, admin_home_1.AdminHome, new_university_component_1.NewUniversity, new_department_component_1.NewDepartment, new_employee_1.NewEmployee, add_role_component_1.AddRole, existing_department_component_1.ExistingDepartment, planner_home_1.PlannerHome, initial_setup_1.InitialStetup, cycle_1.CycleComponent, objective_1.ObjectiveComponent, coordinator_home_1.CoordinatorHome,
                hod_home_1.HodHome, objective_component_1.Objective],
            bootstrap: [app_component_1.AppComponent],
            providers: [login_guard_1.LoggedInGuard, credential_service_1.CredentialService, common_service_1.CommonService, admin_service_1.AdminService, organization_service2_1.OrganizationService2, cycle_check_1.HaveCycle,
                {
                    provide: default_header_service_1.CustomHttpService,
                    useFactory: function (backend, defaultOptions) {
                        return new default_header_service_1.CustomHttpService(backend, defaultOptions);
                    },
                    deps: [http_1.XHRBackend, http_1.RequestOptions]
                },
            ]
        }), 
        __metadata('design:paramtypes', [])
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map