"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var organization_service2_1 = require('../../providers/organization.service2');
var common_service_1 = require('../../providers/common.service');
var HodHome = (function () {
    function HodHome(orgSer, cs) {
        var _this = this;
        this.orgSer = orgSer;
        this.cs = cs;
        this.assignedActivities = [];
        this.departments = [];
        this.cs.getData('user_roleInfo').forEach(function (element) {
            _this.departments.push(element.departmentId);
        });
        this.orgSer.fetchAssignedActivity(this.departments).subscribe(function (res) {
            if (res.status != 204) {
                _this.assignedActivities = res;
            }
            else {
                _this.assignedActivities = [];
            }
        });
    }
    HodHome.prototype.logout = function () {
        localStorage.clear();
    };
    HodHome = __decorate([
        core_1.Component({
            selector: 'hod-home',
            templateUrl: './hod.home.html',
            styleUrls: ['./../Coordinator/coordinator.home.css']
        }), 
        __metadata('design:paramtypes', [organization_service2_1.OrganizationService2, common_service_1.CommonService])
    ], HodHome);
    return HodHome;
}());
exports.HodHome = HodHome;
//# sourceMappingURL=hod.home.js.map