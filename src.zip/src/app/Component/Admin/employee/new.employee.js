"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var admin_service_1 = require('../../../providers/admin.service');
var NewEmployee = (function () {
    function NewEmployee(formBuilder, adminService) {
        var _this = this;
        this.formBuilder = formBuilder;
        this.adminService = adminService;
        this.departments = [];
        this.roles = [];
        adminService.getDepartments().subscribe(function (response) {
            if (response.status === 204) {
                _this.departments = [];
                alert("There is not Department Entry yet.\nFirst Feed the entries of Department");
            }
            else {
                _this.departments = response;
            }
        }, function (err) {
            _this.departments = [];
            console.log(err);
        });
        adminService.getRoles().subscribe(function (response) {
            if (response.status === 204) {
                _this.roles = [];
                alert("There is not Roles Entry yet.\nFirst Feed the entries of Roles");
            }
            else {
                _this.roles = response;
            }
        }, function (err) {
            _this.roles = [];
            console.log(err);
        });
        this.newEmployee = this.initForm();
    }
    NewEmployee.prototype.initForm = function () {
        return this.formBuilder.group({
            "firstName": ['', [forms_1.Validators.required]],
            "middleName": ['', []],
            "lastName": ['', [forms_1.Validators.required]],
            "gender": ['', [forms_1.Validators.required]],
            "email": ['', [forms_1.Validators.required]],
            "password": ['', [forms_1.Validators.required]],
            "contactNo": ['', [forms_1.Validators.required]],
            "joiningDate": ['', [forms_1.Validators.required]],
            "employeeRoles": this.formBuilder.array([this.initRoleDepartment()])
        });
    };
    NewEmployee.prototype.initRoleDepartment = function () {
        return this.formBuilder.group({
            "roleId": ['', [forms_1.Validators.required]],
            "departmentId": ['', [forms_1.Validators.required]],
        });
    };
    NewEmployee.prototype.onSubmit = function () {
        var _this = this;
        console.log(this.newEmployee.value);
        this.adminService.addEmployee(this.newEmployee.value).subscribe(function (response) {
            console.log(response);
            $('#empModal').modal('show');
            _this.newEmployee.reset();
        }, function (error) {
            console.log("Somthing went wrong", error);
        });
    };
    NewEmployee = __decorate([
        core_1.Component({
            selector: 'new-employee',
            templateUrl: './new.employee.html',
            styleUrls: ['./new.employee.css']
        }), 
        __metadata('design:paramtypes', [forms_1.FormBuilder, admin_service_1.AdminService])
    ], NewEmployee);
    return NewEmployee;
}());
exports.NewEmployee = NewEmployee;
//# sourceMappingURL=new.employee.js.map